def sorting(num_monol):

	from random import randint

	monol = []

	for i in range(1, num_monol + 1):

		monol.append(i)

	d = randint(8, 15)

	for i in range(d):

		d = randint(0, num_monol - 1)
		d_1 = randint(0, num_monol - 1)

		a = monol[d_1]
		monol[d_1] = monol[d]
		monol[d] = a

	return monol
